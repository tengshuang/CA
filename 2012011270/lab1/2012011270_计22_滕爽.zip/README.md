Directory structure:
	cache.cpp 			code for LAB1
	picture             pictures and data for LAB1
	Report.pdf 			documentation for the experiment
	Report.doc          documentation for the experiment

Usage:
	COMMAND				Written at the last of the Report.pdf


Environments:
	Operating systems: Ubuntu 14.01
	Compiler: g++ 4.6